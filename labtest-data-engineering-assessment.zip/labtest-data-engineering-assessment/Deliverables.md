# Deliverables – Cancer Diagnostics ETL & ML Assessment

---

##  Documentation of Assumptions & Decisions

### Data Cleaning
- **Missing Identifiers:** Null `order_id` and `lab_number` replaced with synthetic unique values to maintain record traceability.
- **Ambiguous Values:** Object fields like `test`, `service`, and `facility` filled with `'Unknown'` to avoid dropping rows with partial information.
- **Date Standardization:** Irregular formats parsed using fuzzy logic. Unrecognizable entries flagged as `'Invalid'` but retained to preserve row-level features.
- **Price Field:** Cleaned by stripping `'ksh'` and converted to integer. Non-numeric or empty values defaulted to 0.
- **Typos in Categories:** Corrected common misspellings (e.g. `Immunohistochem` → `Immunohistochemistry`, `St. Marys` → `St. Mary's Oncology`).

---

## README – ETL Pipeline Summary

### Extract
- Loaded raw CSV using `pandas.read_csv()`.

### Transform
- Handled missing and malformed values across all fields.
- Standardized date formats using a custom function with `pandas.to_datetime()`.
- Cleaned price, normalized categorical features, and corrected text inconsistencies.
- Flagged `'Invalid'` dates and preserved unknown values to avoid data loss.

### Load
- Stored cleaned data into a structured SQLite database named `cleaned_labtest.db` using `sqlite3` and `df.to_sql()`.
- Verified schema and contents through direct SQL queries inside Kaggle.

### Output Artifacts
- `cleaned_dataset.csv` — Cleaned and transformed dataset
- `cleaned_labtest.db` — Structured SQLite database
- `etl_pipeline.py` — Modular ETL implementation script

---

##  Machine Learning Task – Predicting Test Delays

### Use Case
Estimate the number of days between a test’s `creation_date` and its `signout_date` to forecast processing delays.

### Approach
- Created `delay_days` as target variable using difference of standardized dates.
- Dropped invalid or non-parsable dates.
- Engineered features from categorical fields (`facility`, `test_category`, `service`, etc.) and date components (`weekday`, `month`, `is_weekend`).
- Candidate models: Regression-based (Random Forest, XGBoost, Linear Regression)
- Metrics: Mean Absolute Error (MAE), Root Mean Squared Error (RMSE)

This task supports operational insight for diagnostic centers and can guide staffing and prioritization decisions.

---

